Endless Summer Tours - Koh Samui

[![boat rental Samui](../images/index/image_1.png)](/ "boat rental Samui")

[Home](/)

[Sunset Cruise](/sunset-cruise)

[Private Boat Charter](/private-boat-charter)

[PADI Dive Center](/padi-dive-center)

[![boat rental Samui](../images/index/image_1.png)](/ "boat rental Samui")

[Home](/)

[Sunset Cruise](/sunset-cruise)

[Private Boat Charter](/private-boat-charter)

[PADI Dive Center](/padi-dive-center)

[Plus](#)

* [Home](/)
* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

* [Home](/)
* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

![](https://img1.wsimg.com/isteam/ip/8705e31a-681a-4b03-a1ff-b2bbf21bc4d0/ChatGPT%20Image%2012%20avr.%202026%2C%2011_32_41.png/:/rs=w:1535,m)

## About Endless Summer Tours

![Four men jumping off a wooden boat into the water, enjoying a sunny day.](../images/index/image_3.jpg)

Endless Summer Tours was created to offer premium fully private boat experiences in Koh Samui.

Our mission is simple: create unforgettable moments at sea, combining comfort, authenticity and high-quality service.

With an experienced team and a passion for the ocean, we design each experience to exceed expectations.

We believe that the ocean is more than a destination — it is an experience.

## Where the ocean becomes an experience

[![The most exclusive island discovery of Koh Samui for memorable moments with friends and family.](../images/index/image_4.png)](/private-boat-charter)

#### Private Boat Charter

#### Private Boat Charter

#### Private Boat Charter

Enjoy a fully private boat experience and explore Koh Samui’s hidden islands at your own pace.

[![The perfect dive experience just around Koh Samui, where we can find amazing spots around the island.](../images/index/image_5.png)](/padi-dive-center)

#### PADI Dive Center

#### Private Boat Charter

#### Private Boat Charter

Discover the underwater world with our certified PADI instructors. Suitable for beginners and experienced divers.

[![This wonderfull Endless Summer sunset, in Koh Samui will stay for ever in your mind.](../images/index/image_6.png)](/sunset-cruise)

#### Sunset Cruise

#### Private Boat Charter

#### Sunset Cruise

Experience the most beautiful sunsets in Koh Samui aboard a unique traditional wooden boat for private cruises

![Enjoy the day, stay cool, snorkel, dive, play, live, be happy, Koh Samui](https://img1.wsimg.com/isteam/ip/8705e31a-681a-4b03-a1ff-b2bbf21bc4d0/WOOD-PASSENGER-BOAT-BANGTAO-006-1878080.jpg/:/rs=w:1535,m)

![The best time for a good party with friends and family](https://img1.wsimg.com/isteam/ip/8705e31a-681a-4b03-a1ff-b2bbf21bc4d0/WOOD-PASSENGER-BOAT-BANGTAO-004.jpg/:/rs=w:1535,m)

![Wonderfull beach around Koh Samui onboard Endless Summer.](https://img1.wsimg.com/isteam/ip/8705e31a-681a-4b03-a1ff-b2bbf21bc4d0/ChatGPT%20Image%2021%20avr.%202026%2C%2016_18_39.png/:/rs=w:1535,m)

![Wonderfull day trip on a private boat in Koh Samui. Endless summer is the best boat experience.](https://img1.wsimg.com/isteam/ip/8705e31a-681a-4b03-a1ff-b2bbf21bc4d0/ChatGPT%20Image%2021%20avr.%202026%2C%2023_24_27.png/:/rs=w:1535,m)

![So classy, Endless Summer Experience](https://img1.wsimg.com/isteam/ip/8705e31a-681a-4b03-a1ff-b2bbf21bc4d0/WOOD-PASSENGER-BOAT-BANGTAO-018.jpg/:/rs=w:1535,m)

![The best sunset in Koh Samui onboard Endless Summer for a amazing private cruise](https://img1.wsimg.com/isteam/ip/8705e31a-681a-4b03-a1ff-b2bbf21bc4d0/ChatGPT%20Image%209%20avr.%202026%2C%2005_02_06.png/:/rs=w:1535,m)

## Contact

#### Send you an message

Name

Email\*

Send

Ce site est protégé par reCAPTCHA ; la [Politique de confidentialité](https://policies.google.com/privacy) et les [Conditions d'utilisation](https://policies.google.com/terms) de Google s’appliquent.

#### Better yet, see us in person!

Ready to experience Koh Samui from the sea?

Contact us to book your fully private boat experience, diving or sunset cruise. We respond quickly and help you design the perfect experience.

[Contact us on WhatsApp](https://wa.me/66937833489)

#### Endless Summer Tours

Endless Summer Tours – Private Boat Tours & Diving Koh Samui, Mae Nam, Ko Samui, Province de Surat Thani, Thaïlande

TAT license number : 42/[00594](tel:00594)
Mobile : [+66 93 783 3489](tel:+66937833489)

#### Opening hours

|  |  |  |
| --- | --- | --- |
| Ouvert aujourd'hui | 08:00 – 21:00 |  |

|  |  |
| --- | --- |
| `←` | Move left |
| `→` | Move right |
| `↑` | Move up |
| `↓` | Move down |
| `+` | Zoom in |
| `-` | Zoom out |
| `Home` | Jump left by 75% |
| `End` | Jump right by 75% |
| `Page Up` | Jump up by 75% |
| `Page Down` | Jump down by 75% |

![](https:../images/index/image_8.png)

![](../images/index/image_9.png)

- 
- 
- 
- 
- 
- 

")

Keyboard shortcuts

Map DataMap data ©2026

Map data ©2026

500 m

Click to toggle between metric and imperial units

[Terms](https://www.google.com/intl/en-US_US/help/terms_maps.html)

Obtenez des instructions

Copyright © 2026 Endless Summer Tours - Koh Samui - Tous droits réservés.

Optimisé par

* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

#### Ce site Web utilise les cookies.

Nous utilisons des cookies pour analyser le trafic du site Web et optimiser votre expérience du site. Lorsque vous acceptez notre utilisation des cookies, vos données seront agrégées avec toutes les autres données utilisateur.

RefuserAccepter