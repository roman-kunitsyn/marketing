Endless Summer Tours - Koh Samui - Advanced Open Water, Scuba Diving, Diving Course

[![boat rental Samui](../images/padi-dive-center/image_1.png)](/ "boat rental Samui")

[Home](/)

[Sunset Cruise](/sunset-cruise)

[Private Boat Charter](/private-boat-charter)

[PADI Dive Center](/padi-dive-center)

[![boat rental Samui](../images/padi-dive-center/image_1.png)](/ "boat rental Samui")

[Home](/)

[Sunset Cruise](/sunset-cruise)

[Private Boat Charter](/private-boat-charter)

[PADI Dive Center](/padi-dive-center)

[Plus](#)

* [Home](/)
* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

* [Home](/)
* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

![A scuba diver exploring a vibrant coral reef filled with colorful fish.](../images/padi-dive-center/image_3.png)

# Discover Scuba Diving in Koh Samui with our PADI Dive Center

#### PADI Dive Center Koh Samui | Scuba Diving Experiences

Explore the underwater world of Koh Samui with Endless Summer Experiences, your premium PADI Dive Center dedicated to safe, high-quality and unforgettable diving experiences.

Whether you are discovering scuba diving for the first time or you are already a certified diver, our team is here to guide you through some of the most beautiful diving spots in the Gulf of Thailand.

Koh Samui offers warm tropical waters, diverse marine life and accessible dive sites suitable for all experience levels. From colorful coral reefs and tropical fish to deeper exploration sites, every dive reveals a unique side of the island.

Our philosophy is simple: combine professionalism, safety and personalized service to create diving experiences that are both exciting and relaxing. We intentionally focus on quality rather than volume, allowing us to provide a more comfortable, human and enjoyable atmosphere for our guests.

For beginners, our introductory diving experiences are designed to make you feel confident and comfortable underwater from the very first moment. Our certified PADI instructors accompany you step by step, ensuring a safe and enjoyable introduction to scuba diving.

For certified divers, we organize guided dives adapted to your level and expectations, with access to some of the region’s most interesting underwater environments.

Beyond diving itself, we believe the experience matters just as much as the destination. That is why we combine our diving activities with the comfort and charm of our traditional wooden boat, offering a unique atmosphere before and after each dive.

Whether you are looking for adventure, discovery or simply a new perspective on Koh Samui, our dive center is designed to deliver memorable ocean experiences in a premium and relaxed environment.

#### Start your diving adventure in Koh Samui today

* Discover Scuba Diving for beginners
* Certified diver fun dives
* Private diving experiences
* Small groups and personalized service
* Professional PADI instructors
* Premium boat experience

[Book Now](/#27fb9760-22ef-461c-8ee7-e770a508a27f)

## Choose your Endless Summer scuba diving experience

[The PADI Open Water Diver Course - 18.200 baht per person](/padi-dive-center#ab330bf3-8be1-4d4c-9a5f-7afcc41947f4)[Refresher Course Endless Summer Divers - 2.900 baht per person](/padi-dive-center#1063af69-73df-4b88-b5bd-e1ed054c1ae9)[PADI Advanced Open Water Diver - 14.200 baht per person](/padi-dive-center#384fae46-5aa7-4ea5-abe7-d4ca59a18bbb)[Five Adventure Endless Summer Dives](/padi-dive-center#f90ed727-737d-4f38-811b-e12eeda934ae)[Ang Thong National Marine Park Dives - From 4,800 baht per person](/padi-dive-center#a662aaf2-47e1-4343-9ea8-8d93d77b6ccb)

## The PADI Open Water Diver Course

The PADI Open Water Diver course with Endless Summer Divers on Koh Samui is the globe’s leading scuba certification and the gateway to endless underwater exploration. After finishing the program you’ll be a certified diver, able to dive with a buddy up to 18 metres deep anywhere in the world.

Located in the centre of the Gulf of Thailand, Koh Samui is about a 90 minute boat ride from top dive destinations such as Sail Rock, Koh Tao and Chumphon Pinnacle an ideal setting to learn scuba in Southeast Asia.

#### Course structure

**Before you arrive PADI eLearning**

We’ll send your eLearning access code as soon as you book. Complete the PADI online theory at your own pace (typically 8–10 hours) before you get to Koh Samui. Topics include dive physics, equipment, skills and safety.

**Day 1 Confined water (pool)**

Pool session runs 9:00 am to around noon. Under one-on-one instructor supervision you’ll practise all required PADI skills in a calm, controlled environment: buoyancy, regulator and mask clearing, emergency ascents, and more.

**Days 2 & 3 Open water dives (4 dives total)**

Two boat days to finish four PADI open water dives at sites between Koh Samui and Koh Tao, featuring coral reefs and frequent sightings of tropical fish, turtles and reef sharks. We arrange hotel pickup; boats depart ~9:00 am and return by 3–4:00 pm.

**Junior divers**

- Ages 12–14: certified to 18 m. Ages 10–11: certified to 12 m. Refer to the PADI Junior Open Water Diver standards.

**Optional add-on**

- PADI Enriched Air (Nitrox) can be combined with your course to extend bottom time from your first certification.

#### What's included

* PADI eLearning materials and access
* PADI certification fees
* Hotel transfers to/from your resort
* Professional dive instructor
* Dive computer rental
* 4 open water dives
* Dive insurance
* All scuba equipment
* Lunch and drinks on boat days

## Refresher Course Endless Summer Divers

If you’re a certified diver who hasn’t been underwater for a while, our Diving Refresher at Endless Summer Divers will help you regain confidence. In a brief, guided session an instructor will refresh your skills, review essential safety procedures, and rebuild muscle memory so you return to diving calm, competent, and ready to enjoy the ocean.

#### Who is the Refresher Course for?

* Certified PADI (or equivalent) divers who haven’t dived in 6–12 months and want to regain comfort in the water
* Divers who feel uncertain about their skills before joining a guided dive or liveaboard
* Divers who were certified years ago and want a skills update before a holiday in Koh Samui
* Anyone who experienced a negative dive and wants to rebuild confidence gradually

You must hold a current PADI or equivalent certification this course is a skills refresher, not a recertification.

#### What does the Refresher Course includes?

With a PADI instructor you will:

* Refresh dive fundamentals buoyancy, pressure effects, and safe dive practices
* Check and assemble gear BCD, regulator, dive computer and pre-dive checks
* Practice confined-water skills buoyancy control, mask clearing, regulator recovery and slow, controlled ascents
* Run through emergency responses controlled emergency swimming ascent (CESA), deploying a DSMB, and managing common problems

Schedule: 09:00–12:00 (3 hours) short theory recap followed by in-water practice. Most divers regain confidence within this session.

#### What's included

* Review of dive theory
* In water skills review
* Equipment familiarization
* Instructor supervision

#### What's not included

* Dive equipment rental (available separately)
* Towels
* Swimwear

## PADI Advanced Open Water Diver

The PADI Advanced Open Water course is the natural progression after your Open Water certification. Over 2–3 days you’ll increase your depth limit from 18m to 30m, hone navigation and buoyancy skills, and complete five adventure dives across different specialty areas.

There’s no written exam just guided diving. From Koh Samui you’ll enjoy boat trips to top sites such as Sail Rock, Koh Tao, and Chumphon Pinnacle some of the finest dive locations in the Gulf of Thailand.

#### Why take the PADI Advanced Open Water course?

* Dive deeper extend your maximum depth to 30m to explore wrecks, walls, and deeper sites reserved for advanced divers
* Improve skills refine underwater navigation and situational awareness to dive more confidently
* Gain experience five supervised adventure dives with a qualified PADI instructor
* Progression required before Rescue Diver and opens access to a wider range of dive sites worldwide!

#### Mandatory adventure dives

* Deep Adventure Dive descend to 30m with your instructor to experience depth effects, recognise signs of narcosis, and practise gas management.
* Underwater Navigation master compass work and natural navigation to move confidently and accurately underwater.

#### Choose three elective adventure dives from popular options

* Peak Performance Buoyancy perfect trim and reduce air consumption
* Search & Recovery learn search patterns and safe recovery techniques
* Fish Identification ID the Gulf of Thailand’s key species
* Underwater Naturalist read reef ecology and species interactions
* Wreck Diver  explore wrecks safely and responsibly
* Enriched Air Nitrox extend bottom time and reduce nitrogen load

#### Course format and logistics

* Day 1: eLearning review plus in-water starts (typically Deep + Navigation at local sites)
* Days 2–3: Three elective dives from the boat to top sites (Sail Rock, Koh Tao, Chumphon Pinnacle) depending on conditions and choices
* Hotel pickup included; boat departures around 09:00, returning ~15:00–16:00

#### What's next?

Your Advanced Open Water certification is the required step toward PADI Rescue Diver and lets you access deeper, more adventurous dive sites on our tours.

#### More details

* Duration 2-3 days
* Minimum age 12+
* Maximum depth 30 meters
* Certification : Advanced Open Water Diver
* Prerequisites : PADI Open Water Diver certification (or equivalent)

## Five Adventure Endless Summer Dives

Get ready for five thrilling dives that boost your skills and open up new underwater playgrounds.

#### Mandatory adventure dives

* Deep Adventure Dive together with your instructor you’ll descend to 30m to experience deeper environments, recognise narcosis signs, and practise smart gas management.
* Underwater Navigation hone compass techniques and natural navigation so you can move around a site with precision and confidence.

#### Pick three elective adventure dives from our favourites

* Peak Performance Buoyancy dial in your trim and breathing to glide effortlessly and save air
* Search & Recovery learn systematic search patterns and safe object recovery techniques
* Fish Identification spot and identify the Gulf of Thailand’s most common and colourful species
* Underwater Naturalist discover reef relationships and the stories behind the marine life you see
* Wreck Diver safely explore shipwrecks and learn site-specific techniques
* Enriched Air Nitrox dive longer and reduce nitrogen exposure with Nitrox training

Each dive is guided by a PADI instructor and designed to be hands on, fun, and confidence building.

#### What's included

* PADI eLearning materials
* PADI certification fees
* Hotel transfers
* Professional dive instructor
* 5 adventure dives (incl. Deep dive to 30m and Underwater Navigation)
* Dive computer rental
* Dive insurance
* All scuba equipment
* Lunch and drinks on boat days

#### What's not included

* Towels
* Swimwear
* Sunscreen

## Ang Thong National Marine Park Dives

Ang Thong National Marine Park bursts from the sea 42 rugged islands crowned with sheer limestone cliffs, secret emerald lagoons, and powder white beaches. Below the surface you'll find some of the Gulf’s most pristine coral gardens, teeming with life and rarely visited by dive crowds. Unlike busier sites, Ang Thong’s protected waters offer quieter dives, clearer reefs, and the chance to encounter relaxed, abundant marine life in a dramatically beautiful, almost untouched seascape.

#### Why Dive Ang Thong Marine Park?

* Pristine, protected reefs swim over some of the Gulf’s healthiest, least-touched coral gardens where life thrives undisturbed
* Epic scenery above and below towering limestone cliffs, hidden emerald lagoons and powder white beaches make every surface interval a photo moment
* Rich marine encounters spot parrotfish, wrasse, stingrays, morays, butterflyfish, reef sharks and the occasional banded sea snake amid colourful hard and soft corals
* Feel like an explorer far fewer boats and divers than Sail Rock or Koh Tao means quieter sites and a more intimate, wild experience
* Perfect for newer divers many sites are shallow (to ~20m) with calm conditions, ideal for Open Water level adventures

#### Dive Sites

Routes change with the weather and tides, but expect to explore hidden reefs tucked between the archipelago’s islands calm, clear waters and intact coral gardens waiting to be discovered at 5–20m. Each site feels like a new secret to uncover.

Note: Trips run as custom tours because of park permits and access rules. Contact us for dates and group bookings.

#### Itinerary

* 07:45–08:30 — Hotel pickup across Koh Samui
* 08:30–09:00 — Embark and brief the day’s plan
* 09:00–10:00 — Scenic boat run to Ang Thong (~60 minutes)
* 10:00–11:30 — First dive descend into secluded coral valleys (briefing included)
* 11:30–12:30 Surface interval & lunch on board among limestone cliffs
* 12:30–13:30 — Second dive more exploration of pristine reefs and swim-throughs
* 13:30–14:30 Cruise back toward Koh Samui
* 14:30–15:30 Return to your hotel

Safety: Do not fly within 18 hours of your final dive.

#### What's included

* Hotel transfer to and from your resort
* 2 dives
* Diving insurance
* Rental of all dive equipment
* Free soft drinks
* Lunch onboard \*Vegetarian and vegan options available

#### What's not included

* Towels
* Swimwear
* Dive computer
* Sunscreen

## Contact

#### Send you an message

Name

Email\*

Send

Ce site est protégé par reCAPTCHA ; la [Politique de confidentialité](https://policies.google.com/privacy) et les [Conditions d'utilisation](https://policies.google.com/terms) de Google s’appliquent.

#### Better yet, see us in person!

Ready to experience Koh Samui from the sea?

Contact us to book your fully private boat experience, diving or sunset cruise. We respond quickly and help you design the perfect experience.

[Contact us on WhatsApp](https://wa.me/66937833489)

#### Endless Summer Tours - Koh Samui

Endless Summer Tours – Private Boat Tours & Diving Koh Samui, Mae Nam, Ko Samui, Province de Surat Thani, Thaïlande

TAT license number : 42/[00594](tel:00594)
Mobile : [+66 93 783 3489](tel:+66937833489)

#### Opening hours

|  |  |  |
| --- | --- | --- |
| Ouvert aujourd'hui | 08:00 – 21:00 |  |

|  |  |
| --- | --- |
| `←` | Move left |
| `→` | Move right |
| `↑` | Move up |
| `↓` | Move down |
| `+` | Zoom in |
| `-` | Zoom out |
| `Home` | Jump left by 75% |
| `End` | Jump right by 75% |
| `Page Up` | Jump up by 75% |
| `Page Down` | Jump down by 75% |

![](https:../images/padi-dive-center/image_5.png)

![](../images/padi-dive-center/image_6.png)

- 
- 
- 
- 
- 
- 

")

Keyboard shortcuts

Map DataMap data ©2026

Map data ©2026

500 m

Click to toggle between metric and imperial units

[Terms](https://www.google.com/intl/en-US_US/help/terms_maps.html)

Obtenez des instructions

Copyright © 2026 Endless Summer Tours - Koh Samui - Tous droits réservés.

Optimisé par

* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

#### Ce site Web utilise les cookies.

Nous utilisons des cookies pour analyser le trafic du site Web et optimiser votre expérience du site. Lorsque vous acceptez notre utilisation des cookies, vos données seront agrégées avec toutes les autres données utilisateur.

RefuserAccepter