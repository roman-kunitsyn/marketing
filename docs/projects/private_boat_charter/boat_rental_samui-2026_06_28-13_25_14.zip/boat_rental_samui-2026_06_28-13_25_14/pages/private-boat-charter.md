Endless Summer Experience - Koh Samui - Private Cruises, Dive Center, Sunset Cruises

[![boat rental Samui](../images/private-boat-charter/image_1.png)](/ "boat rental Samui")

[Home](/)

[Sunset Cruise](/sunset-cruise)

[Private Boat Charter](/private-boat-charter)

[PADI Dive Center](/padi-dive-center)

[![boat rental Samui](../images/private-boat-charter/image_1.png)](/ "boat rental Samui")

[Home](/)

[Sunset Cruise](/sunset-cruise)

[Private Boat Charter](/private-boat-charter)

[PADI Dive Center](/padi-dive-center)

[Plus](#)

* [Home](/)
* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

* [Home](/)
* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

![Wooden boat floating on clear turquoise water near a lush green island under a bright blue sky.](../images/private-boat-charter/image_3.png)

# Private Boat Island Exploration

#### Welcome onboard Endless Summer

Discover Koh Samui in the most exclusive way with a private boat charter designed entirely around your desires.

Far from crowded tours and fixed itineraries, our private experiences offer complete freedom, comfort and flexibility. Whether you are planning a romantic escape, a day with family or a celebration with friends, we create a tailor-made journey adapted to your expectations.

Step aboard our traditional wooden boat and explore the most beautiful islands and hidden spots around Koh Samui. Cruise along pristine coastlines, discover secluded beaches, swim in crystal-clear waters and enjoy the ocean at your own rhythm. Every itinerary is customizable, allowing you to choose between relaxation, exploration or a mix of both.

Our private charters are designed to deliver a premium experience from start to finish. The boat combines authentic charm with comfort, offering spacious areas to relax, sunbathe or simply enjoy the view. The calm atmosphere at sea, combined with breathtaking landscapes, creates the perfect setting for unforgettable moments.

Depending on your preferences, your experience can include snorkeling stops to discover vibrant marine life, visits to nearby islands, or simply time to unwind in peaceful and uncrowded locations. Our crew is here to guide you and ensure that every moment runs smoothly, while giving you the space to enjoy your day exactly as you wish.

Safety and quality are at the heart of everything we do. Our experienced team takes care of every detail, from navigation to service on board, ensuring a seamless and worry-free experience.

A private boat cruise in Koh Samui is more than just a tour — it is a unique opportunity to experience the island differently, away from the crowds, in total comfort and privacy.

#### Book your Tour

* Fully private experience
* Flexible itinerary tailored to you
* Access to hidden islands and beaches
* Swimming and snorkeling opportunities
* Premium service and experienced crew

Book your private boat charter and design your perfect day at sea

[Book Now](/#27fb9760-22ef-461c-8ee7-e770a508a27f)

## Half-Day Wooden Trawler — Endless Summer

![](../images/private-boat-charter/image_4.png)

#### Overview

Picture-perfect cruising, snorkeling and beach bliss — arrive to a chilled fresh coconut and leave with a camera full of memories.

#### Quick info

* Meeting / Pickup: Minibus pickups begin ~08:00 (exact time depends on your hotel location).
* Departure: Petcharat Marina, 09:00.
* Return: Petcharat Marina by 14:00, then hotel drop-offs.
* Group size: Intimate: max 15 guests.
* Price: 2,900 Baht per person (wristband included).
* Return to Petcharat Marina with hotel drop‑offs, arriving by 14:00.

#### What’s Included

* Roundtrip hotel transfer by comfortable van (pickup from ~08:00).
* Scenic cruise aboard an elegant wooden trawler (max 15 guests).
* Welcome fresh coconut on boarding — the first taste of island life.
* Gourmet healthy lunch finished with seasonal fruit.
* Complimentary soft drinks (beer & piña coladas available to purchase).
* Snorkeling equipment for every guest.
* Large double floating beanbags/pillows for ultimate water lounging.
* Kids’ supervised snorkeling introductory course (ages 4–11).
* Professional guide, full activity supervision and safety briefings.
* Travel and medical insurance.
* Trip wristband and all necessary safety equipment.

#### Itinerary (summary)

* 08:00 — Van pickups begin (please be ready 10 minutes early).
* 09:00 — Assemble at Petcharat Marina and set sail with a fresh coconut in hand.
* Morning cruise past the iconic Big Buddha — perfect photo + video stops with sweeping coastal panoramas of Koh Faan and the northern shoreline.
* Southward along dramatic headlands toward Silver Beach, pausing at scenic viewpoints.
* Silver Beach stop — snorkel vibrant reefs, float on plush double beanbags, or take a short dinghy ride ashore to explore soft sand and hidden coves. Children can join a fun, supervised snorkeling class.
* Lunch on board — a delicious, health-forward spread with seasonal fruit. Relax, swim, snorkel, and soak up the sun.
* Return to Petcharat Marina by 14:00, followed by hotel drop-offs.

#### Photo & activity highlights

* Golden sunrise light and epic Big Buddha vistas — endless Instagram moments.
* Dramatic coastal panoramas and local fishing life for authentic storytelling shots.
* Crystal-clear snorkeling over colorful reef life — underwater frames you’ll want to share.
* Lounging on chic double floating beanbags — laid-back luxury on the water.
* Family-friendly moments: little ones learning to snorkel while you relax.

#### What to bring (not included)

* Personal towel(s) and swimwear.
* Coral-friendly sunscreen (required).
* Hat, sunglasses, and any personal medications.
* Optional: waterproof camera, cash for premium drinks, and tips.

#### Safety & notes

* Children must be supervised; kids’ snorkel course run by trained staff.
* Please be ready for pickup 10 minutes before your scheduled time.
* All guests must follow crew safety briefings and wear provided safety equipment when instructed.

## Food Menu

### Traditionnal Thai Dishes

![](../images/private-boat-charter/image_5.jpg)

#### Grilled Veggie Pesto Pasta

![](../images/private-boat-charter/image_7.jpg)

#### Clean Fried Rice Chicken

![](../images/private-boat-charter/image_9.jpg)

#### Teriyaki Beef

![](../images/private-boat-charter/image_11.jpg)

#### Sesame Crusted Salmon

---

### Home-made Wraps

![](../images/private-boat-charter/image_13.jpg)

#### Big Fat Salad Wrap

![](../images/private-boat-charter/image_15.jpg)

#### Salmon & Egg Wrap

![](../images/private-boat-charter/image_17.jpg)

#### Big Fat Salad Chicken Wrap

![](../images/private-boat-charter/image_19.jpg)

#### Grilled Chicken Caesar Wrap

![](../images/private-boat-charter/image_21.jpg)

#### Satay Chicken Wrap

All you dishes or wraps must be ordered during the booking, maximum at 4pm the day before

## Contact

#### Send you an message

Name

Email\*

Send

Ce site est protégé par reCAPTCHA ; la [Politique de confidentialité](https://policies.google.com/privacy) et les [Conditions d'utilisation](https://policies.google.com/terms) de Google s’appliquent.

#### Better yet, see us in person!

Ready to experience Koh Samui from the sea?

Contact us to book your fully private boat experience, diving or sunset cruise. We respond quickly and help you design the perfect experience.

[Contact us on WhatsApp](https://wa.me/66937833489)

#### Endless Summer Tours - Koh Samui

Endless Summer Tours – Private Boat Tours & Diving Koh Samui, Mae Nam, Ko Samui, Province de Surat Thani, Thaïlande

TAT license number : 42/[00594](tel:00594)
Mobile : [+66 93 783 3489](tel:+66937833489)

#### Opening hours

|  |  |  |
| --- | --- | --- |
| Ouvert aujourd'hui | 08:00 – 21:00 |  |

|  |  |
| --- | --- |
| `←` | Move left |
| `→` | Move right |
| `↑` | Move up |
| `↓` | Move down |
| `+` | Zoom in |
| `-` | Zoom out |
| `Home` | Jump left by 75% |
| `End` | Jump right by 75% |
| `Page Up` | Jump up by 75% |
| `Page Down` | Jump down by 75% |

![](https:../images/private-boat-charter/image_24.png)

![](../images/private-boat-charter/image_25.png)

- 
- 
- 
- 
- 
- 

")

Keyboard shortcuts

Map DataMap data ©2026

Map data ©2026

500 m

Click to toggle between metric and imperial units

[Terms](https://www.google.com/intl/en-US_US/help/terms_maps.html)

Obtenez des instructions

Copyright © 2026 Endless Summer Tours - Koh Samui - Tous droits réservés.

Optimisé par

* [Sunset Cruise](/sunset-cruise)
* [Private Boat Charter](/private-boat-charter)
* [PADI Dive Center](/padi-dive-center)

#### Ce site Web utilise les cookies.

Nous utilisons des cookies pour analyser le trafic du site Web et optimiser votre expérience du site. Lorsque vous acceptez notre utilisation des cookies, vos données seront agrégées avec toutes les autres données utilisateur.

RefuserAccepter